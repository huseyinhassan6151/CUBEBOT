const fs = require('fs');
const path = require('path');

function loadCommands(client) {
  client.commands = new Map();
  const commandsPath = path.join(__dirname, '..', 'commands');
  const categories = fs.readdirSync(commandsPath);

  for (const category of categories) {
    const categoryPath = path.join(commandsPath, category);
    if (!fs.statSync(categoryPath).isDirectory()) continue;

    const files = fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'));
    for (const file of files) {
      const command = require(path.join(categoryPath, file));
      if (!command?.data || !command?.execute) {
        console.warn(`[Commands] Skipping invalid command file: ${category}/${file}`);
        continue;
      }
      client.commands.set(command.data.name, command);
    }
  }

  console.log(`[Commands] Loaded ${client.commands.size} slash commands.`);
}

function getAllCommandData() {
  const commandsPath = path.join(__dirname, '..', 'commands');
  const categories = fs.readdirSync(commandsPath);
  const data = [];

  for (const category of categories) {
    const categoryPath = path.join(commandsPath, category);
    if (!fs.statSync(categoryPath).isDirectory()) continue;

    const files = fs.readdirSync(categoryPath).filter(f => f.endsWith('.js'));
    for (const file of files) {
      const command = require(path.join(categoryPath, file));
      if (command?.data) data.push(command.data.toJSON());
    }
  }
  return data;
}

module.exports = { loadCommands, getAllCommandData };
