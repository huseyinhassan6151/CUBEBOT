const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle
} = require('discord.js');
const GuildConfig = require('../models/GuildConfig');
const Ticket = require('../models/Ticket');
const { colors, tickets: ticketConfig } = require('../config/config');

async function getOrCreateGuildConfig(guildId) {
  let cfg = await GuildConfig.findOne({ guildId });
  if (!cfg) cfg = await GuildConfig.create({ guildId });
  return cfg;
}

function ticketPanelEmbed(guild) {
  return new EmbedBuilder()
    .setColor(colors.primary)
    .setTitle('🎫 Support Tickets')
    .setDescription(
      `Need help? Click the button below to open a private ticket with the **${guild.name}** team.\n\n` +
      `Please only open a ticket if you have a genuine question or issue.`
    )
    .setFooter({ text: 'CUBEBOT Ticket System' });
}

function ticketPanelRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('ticket_open')
      .setLabel('Open Ticket')
      .setEmoji('🎫')
      .setStyle(ButtonStyle.Primary)
  );
}

function ticketReasonModal() {
  return new ModalBuilder()
    .setCustomId('ticket_open_modal')
    .setTitle('Open a Support Ticket')
    .addComponents(
      new ActionRowBuilder().addComponents(
        new TextInputBuilder()
          .setCustomId('ticket_reason')
          .setLabel('What do you need help with?')
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder('Describe your issue briefly...')
          .setRequired(true)
          .setMaxLength(500)
      )
    );
}

async function createTicket(interaction, reason) {
  const { guild, user } = interaction;
  const cfg = await getOrCreateGuildConfig(guild.id);

  const openCount = await Ticket.countDocuments({ guildId: guild.id, userId: user.id, status: 'open' });
  if (openCount >= ticketConfig.maxOpenPerUser) {
    return interaction.reply({
      content: `❌ You already have ${openCount} open ticket(s). Please close them before opening a new one.`,
      ephemeral: true
    });
  }

  await interaction.deferReply({ ephemeral: true });

  let category = cfg.tickets.categoryId ? guild.channels.cache.get(cfg.tickets.categoryId) : null;
  if (!category) {
    category = await guild.channels.create({
      name: ticketConfig.categoryName,
      type: ChannelType.GuildCategory
    });
    cfg.tickets.categoryId = category.id;
    await cfg.save();
  }

  cfg.tickets.ticketCounter += 1;
  await cfg.save();
  const ticketNumber = cfg.tickets.ticketCounter;

  const permissionOverwrites = [
    { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    {
      id: user.id,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles
      ]
    },
    {
      id: interaction.client.user.id,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels]
    }
  ];

  for (const roleId of cfg.tickets.supportRoleIds) {
    permissionOverwrites.push({
      id: roleId,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
    });
  }

  const channel = await guild.channels.create({
    name: `ticket-${ticketNumber}`,
    type: ChannelType.GuildText,
    parent: category.id,
    permissionOverwrites
  });

  await Ticket.create({
    guildId: guild.id,
    channelId: channel.id,
    userId: user.id,
    ticketNumber,
    reason: reason || 'No reason provided'
  });

  const embed = new EmbedBuilder()
    .setColor(colors.primary)
    .setTitle(`🎫 Ticket #${ticketNumber}`)
    .setDescription(`Hello ${user}, thanks for reaching out!\n\n**Reason:** ${reason || 'No reason provided'}\n\nSupport will be with you shortly.`)
    .setTimestamp();

  const controlRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId('ticket_claim').setLabel('Claim').setEmoji('🙋').setStyle(ButtonStyle.Secondary),
    new ButtonBuilder().setCustomId('ticket_close').setLabel('Close').setEmoji('🔒').setStyle(ButtonStyle.Danger)
  );

  await channel.send({ content: `${user}`, embeds: [embed], components: [controlRow] });
  await interaction.editReply({ content: `✅ Your ticket has been created: ${channel}` });
}

async function claimTicket(interaction) {
  const ticket = await Ticket.findOne({ channelId: interaction.channel.id, status: 'open' });
  if (!ticket) return interaction.reply({ content: '❌ This is not an active ticket.', ephemeral: true });

  ticket.claimedBy = interaction.user.id;
  await ticket.save();

  await interaction.reply({ content: `🙋 This ticket has been claimed by ${interaction.user}.` });
}

async function closeTicket(interaction) {
  const ticket = await Ticket.findOne({ channelId: interaction.channel.id, status: 'open' });
  if (!ticket) return interaction.reply({ content: '❌ This is not an active ticket.', ephemeral: true });

  await interaction.reply({ content: '🔒 Closing this ticket in 5 seconds...' });

  ticket.status = 'closed';
  ticket.closedBy = interaction.user.id;
  ticket.closedAt = new Date();
  await ticket.save();

  const cfg = await getOrCreateGuildConfig(interaction.guild.id);
  if (cfg.tickets.logChannelId) {
    const logChannel = interaction.guild.channels.cache.get(cfg.tickets.logChannelId);
    if (logChannel) {
      const embed = new EmbedBuilder()
        .setColor(colors.dark)
        .setTitle(`Ticket #${ticket.ticketNumber} Closed`)
        .addFields(
          { name: 'Opened by', value: `<@${ticket.userId}>`, inline: true },
          { name: 'Closed by', value: `${interaction.user}`, inline: true },
          { name: 'Reason', value: ticket.reason || 'N/A' }
        )
        .setTimestamp();
      await logChannel.send({ embeds: [embed] });
    }
  }

  setTimeout(() => {
    interaction.channel.delete().catch(() => {});
  }, 5000);
}

module.exports = {
  getOrCreateGuildConfig,
  ticketPanelEmbed,
  ticketPanelRow,
  ticketReasonModal,
  createTicket,
  claimTicket,
  closeTicket
};
