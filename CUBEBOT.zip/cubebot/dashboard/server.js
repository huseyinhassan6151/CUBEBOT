require('dotenv').config();
const express = require('express');
const session = require('express-session');
const passport = require('passport');
const MongoStore = require('connect-mongo');
const path = require('path');
const { Strategy: DiscordStrategy } = require('passport-discord');

const GuildConfig = require('../models/GuildConfig');
const User = require('../models/User');
const Ticket = require('../models/Ticket');
const { connectDatabase } = require('../database/connect');
const { ownerIds } = require('../config/config');

const app = express();
const PORT = process.env.DASHBOARD_PORT || 3000;

// ===== Passport / Discord OAuth2 =====
passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj, done) => done(null, obj));

passport.use(new DiscordStrategy({
  clientID: process.env.CLIENT_ID,
  clientSecret: process.env.CLIENT_SECRET,
  callbackURL: process.env.DASHBOARD_CALLBACK_URL || `http://localhost:${PORT}/auth/discord/callback`,
  scope: ['identify', 'guilds']
}, (accessToken, refreshToken, profile, done) => {
  process.nextTick(() => done(null, profile));
}));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));

app.use(session({
  secret: process.env.SESSION_SECRET || 'cubebot_secret_change_me',
  resave: false,
  saveUninitialized: false,
  store: process.env.MONGO_URI ? MongoStore.create({ mongoUrl: process.env.MONGO_URI }) : undefined,
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 }
}));
app.use(passport.initialize());
app.use(passport.session());

function checkAuth(req, res, next) {
  if (req.isAuthenticated()) return next();
  res.redirect('/auth/discord');
}

// Only allow guilds where the user has "Manage Server" permission (0x20) or is an owner
function manageableGuilds(user) {
  if (!user?.guilds) return [];
  return user.guilds.filter(g => (BigInt(g.permissions) & BigInt(0x20)) === BigInt(0x20) || g.owner);
}

// ===== Auth Routes =====
app.get('/auth/discord', passport.authenticate('discord'));
app.get('/auth/discord/callback', passport.authenticate('discord', { failureRedirect: '/' }), (req, res) => {
  res.redirect('/dashboard');
});
app.get('/logout', (req, res) => {
  req.logout(() => res.redirect('/'));
});

// ===== Public Routes =====
app.get('/', (req, res) => {
  res.render('index', { user: req.user || null });
});

// ===== Dashboard: Guild List =====
app.get('/dashboard', checkAuth, (req, res) => {
  const guilds = manageableGuilds(req.user);
  res.render('dashboard', { user: req.user, guilds });
});

// ===== Dashboard: Guild Settings =====
app.get('/dashboard/:guildId', checkAuth, async (req, res) => {
  const { guildId } = req.params;
  const guilds = manageableGuilds(req.user);
  const guild = guilds.find(g => g.id === guildId);
  if (!guild) return res.status(403).send('You do not have permission to manage this server.');

  let cfg = await GuildConfig.findOne({ guildId });
  if (!cfg) cfg = await GuildConfig.create({ guildId });

  const memberCount = await User.countDocuments({ guildId });
  const openTickets = await Ticket.countDocuments({ guildId, status: 'open' });

  res.render('guild', { user: req.user, guild, cfg, memberCount, openTickets });
});

// ===== Dashboard: Update Settings =====
app.post('/dashboard/:guildId/welcome', checkAuth, async (req, res) => {
  const { guildId } = req.params;
  const { enabled, channelId, message } = req.body;

  let cfg = await GuildConfig.findOne({ guildId });
  if (!cfg) cfg = await GuildConfig.create({ guildId });

  cfg.welcome.enabled = enabled === 'on';
  cfg.welcome.channelId = channelId || null;
  cfg.welcome.message = message || cfg.welcome.message;
  await cfg.save();

  res.redirect(`/dashboard/${guildId}`);
});

app.post('/dashboard/:guildId/xp', checkAuth, async (req, res) => {
  const { guildId } = req.params;
  const { enabled, announceLevelUp, levelUpChannelId } = req.body;

  let cfg = await GuildConfig.findOne({ guildId });
  if (!cfg) cfg = await GuildConfig.create({ guildId });

  cfg.xpSystem.enabled = enabled === 'on';
  cfg.xpSystem.announceLevelUp = announceLevelUp === 'on';
  cfg.xpSystem.levelUpChannelId = levelUpChannelId || null;
  await cfg.save();

  res.redirect(`/dashboard/${guildId}`);
});

app.post('/dashboard/:guildId/moderation', checkAuth, async (req, res) => {
  const { guildId } = req.params;
  const { logChannelId, automod } = req.body;

  let cfg = await GuildConfig.findOne({ guildId });
  if (!cfg) cfg = await GuildConfig.create({ guildId });

  cfg.moderation.logChannelId = logChannelId || null;
  cfg.moderation.automod = automod === 'on';
  await cfg.save();

  res.redirect(`/dashboard/${guildId}`);
});

// ===== Start server (only if run directly) =====
if (require.main === module) {
  (async () => {
    await connectDatabase();
    app.listen(PORT, () => console.log(`[Dashboard] Running at http://localhost:${PORT}`));
  })();
}

module.exports = app;
