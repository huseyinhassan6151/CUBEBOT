const { xp: xpConfig } = require('../config/config');

// XP required to go from `level` to `level + 1`
function xpForNextLevel(level) {
  return xpConfig.levelUpFormula(level);
}

// Given total accumulated xp, figure out the current level
function levelFromXp(totalXp) {
  let level = 0;
  let remaining = totalXp;
  while (remaining >= xpForNextLevel(level)) {
    remaining -= xpForNextLevel(level);
    level++;
  }
  return level;
}

function randomXpGain() {
  const { minPerMessage, maxPerMessage } = xpConfig;
  return Math.floor(Math.random() * (maxPerMessage - minPerMessage + 1)) + minPerMessage;
}

module.exports = { xpForNextLevel, levelFromXp, randomXpGain };
