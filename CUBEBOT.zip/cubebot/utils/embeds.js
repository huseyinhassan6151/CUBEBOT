const { EmbedBuilder } = require('discord.js');
const { colors } = require('../config/config');

function baseEmbed() {
  return new EmbedBuilder().setTimestamp();
}

function successEmbed(description, title = null) {
  const e = baseEmbed().setColor(colors.success).setDescription(`✅ ${description}`);
  if (title) e.setTitle(title);
  return e;
}

function errorEmbed(description, title = null) {
  const e = baseEmbed().setColor(colors.danger).setDescription(`❌ ${description}`);
  if (title) e.setTitle(title);
  return e;
}

function infoEmbed(description, title = null) {
  const e = baseEmbed().setColor(colors.primary).setDescription(description);
  if (title) e.setTitle(title);
  return e;
}

function warnEmbed(description, title = null) {
  const e = baseEmbed().setColor(colors.warning).setDescription(`⚠️ ${description}`);
  if (title) e.setTitle(title);
  return e;
}

module.exports = { baseEmbed, successEmbed, errorEmbed, infoEmbed, warnEmbed };
