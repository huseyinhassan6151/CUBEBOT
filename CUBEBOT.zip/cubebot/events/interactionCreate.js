const { errorEmbed } = require('../utils/embeds');
const ticketHandler = require('../handlers/ticketHandler');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    try {
      // ===== Slash Commands =====
      if (interaction.isChatInputCommand()) {
        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        try {
          await command.execute(interaction, client);
        } catch (err) {
          console.error(`[Command Error] ${interaction.commandName}:`, err);
          const payload = { embeds: [errorEmbed('Something went wrong while running that command.')], ephemeral: true };
          if (interaction.replied || interaction.deferred) {
            await interaction.followUp(payload).catch(() => {});
          } else {
            await interaction.reply(payload).catch(() => {});
          }
        }
        return;
      }

      // ===== Autocomplete =====
      if (interaction.isAutocomplete()) {
        const command = client.commands.get(interaction.commandName);
        if (command?.autocomplete) {
          await command.autocomplete(interaction, client).catch(() => {});
        }
        return;
      }

      // ===== Buttons =====
      if (interaction.isButton()) {
        const { customId } = interaction;

        if (customId === 'ticket_open') {
          return interaction.showModal(ticketHandler.ticketReasonModal());
        }
        if (customId === 'ticket_claim') {
          return ticketHandler.claimTicket(interaction);
        }
        if (customId === 'ticket_close') {
          return ticketHandler.closeTicket(interaction);
        }
        return;
      }

      // ===== Modals =====
      if (interaction.isModalSubmit()) {
        if (interaction.customId === 'ticket_open_modal') {
          const reason = interaction.fields.getTextInputValue('ticket_reason');
          return ticketHandler.createTicket(interaction, reason);
        }
        return;
      }
    } catch (err) {
      console.error('[InteractionCreate] Unhandled error:', err);
    }
  }
};
