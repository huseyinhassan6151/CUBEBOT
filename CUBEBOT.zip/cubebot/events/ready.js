const { ActivityType } = require('discord.js');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`[CUBEBOT] Logged in as ${client.user.tag}`);
    console.log(`[CUBEBOT] Serving ${client.guilds.cache.size} server(s).`);

    client.user.setPresence({
      activities: [{ name: `/help | CUBEBOT`, type: ActivityType.Watching }],
      status: 'online'
    });
  }
};
