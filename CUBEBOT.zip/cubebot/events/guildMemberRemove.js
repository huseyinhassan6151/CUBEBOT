const { EmbedBuilder } = require('discord.js');
const GuildConfig = require('../models/GuildConfig');
const { colors } = require('../config/config');

function formatMessage(template, member) {
  return template
    .replaceAll('{user}', `${member.user.tag}`)
    .replaceAll('{username}', member.user.username)
    .replaceAll('{server}', member.guild.name)
    .replaceAll('{count}', `${member.guild.memberCount}`);
}

module.exports = {
  name: 'guildMemberRemove',
  async execute(member, client) {
    const cfg = await GuildConfig.findOne({ guildId: member.guild.id });
    if (!cfg?.welcome?.leaveEnabled || !cfg.welcome.leaveChannelId) return;

    const channel = member.guild.channels.cache.get(cfg.welcome.leaveChannelId);
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor(colors.danger)
      .setTitle('👋 Member Left')
      .setDescription(formatMessage(cfg.welcome.leaveMessage, member))
      .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
      .setTimestamp();

    channel.send({ embeds: [embed] }).catch(() => {});
  }
};
