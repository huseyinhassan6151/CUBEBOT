const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const GuildConfig = require('../models/GuildConfig');
const { colors } = require('../config/config');

function formatMessage(template, member) {
  return template
    .replaceAll('{user}', `${member}`)
    .replaceAll('{username}', member.user.username)
    .replaceAll('{server}', member.guild.name)
    .replaceAll('{count}', `${member.guild.memberCount}`);
}

module.exports = {
  name: 'guildMemberAdd',
  async execute(member, client) {
    const cfg = await GuildConfig.findOne({ guildId: member.guild.id });
    if (!cfg?.welcome?.enabled || !cfg.welcome.channelId) return;

    const channel = member.guild.channels.cache.get(cfg.welcome.channelId);
    if (!channel) return;

    const embed = new EmbedBuilder()
      .setColor(colors.success)
      .setTitle('👋 New Member!')
      .setDescription(formatMessage(cfg.welcome.message, member))
      .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
      .setFooter({ text: `Member #${member.guild.memberCount}` })
      .setTimestamp();

    channel.send({ embeds: [embed] }).catch(() => {});
  }
};
