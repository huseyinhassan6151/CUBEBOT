const User = require('../models/User');
const GuildConfig = require('../models/GuildConfig');
const { levelFromXp, randomXpGain } = require('../utils/xp');
const { xp: xpConfig, colors } = require('../config/config');
const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'messageCreate',
  async execute(message, client) {
    if (message.author.bot || !message.guild) return;

    const cfg = await GuildConfig.findOne({ guildId: message.guild.id });

    // ===== Auto Responses =====
    if (cfg?.autoResponses?.length) {
      const content = message.content.toLowerCase().trim();
      for (const ar of cfg.autoResponses) {
        const trigger = ar.trigger.toLowerCase();
        const matched = ar.exactMatch ? content === trigger : content.includes(trigger);
        if (matched) {
          await message.channel.send(ar.response).catch(() => {});
          break;
        }
      }
    }

    // ===== XP System =====
    if (!cfg || cfg.xpSystem.enabled) {
      try {
        let user = await User.findOne({ userId: message.author.id, guildId: message.guild.id });
        if (!user) {
          user = await User.create({ userId: message.author.id, guildId: message.guild.id });
        }

        const now = Date.now();
        const lastMsg = user.lastXpMessage ? new Date(user.lastXpMessage).getTime() : 0;
        const cooldownMs = xpConfig.cooldownSeconds * 1000;

        if (now - lastMsg >= cooldownMs) {
          const gained = randomXpGain();
          const previousLevel = user.level;

          user.xp += gained;
          user.totalMessages += 1;
          user.lastXpMessage = new Date();
          user.level = levelFromXp(user.xp);
          await user.save();

          if (user.level > previousLevel && cfg?.xpSystem?.announceLevelUp !== false) {
            const levelUpChannel = cfg?.xpSystem?.levelUpChannelId
              ? message.guild.channels.cache.get(cfg.xpSystem.levelUpChannelId)
              : message.channel;

            if (levelUpChannel) {
              const embed = new EmbedBuilder()
                .setColor(colors.success)
                .setDescription(`🎉 ${message.author} leveled up to **Level ${user.level}**!`);
              levelUpChannel.send({ embeds: [embed] }).catch(() => {});
            }
          }
        }
      } catch (err) {
        console.error('[XP System] Error:', err.message);
      }
    }
  }
};
