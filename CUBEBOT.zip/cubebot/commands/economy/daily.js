const { SlashCommandBuilder } = require('discord.js');
const User = require('../../models/User');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { economy } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('daily')
    .setDescription('Claim your daily coins reward.'),

  async execute(interaction) {
    let user = await User.findOne({ userId: interaction.user.id, guildId: interaction.guild.id });
    if (!user) user = await User.create({ userId: interaction.user.id, guildId: interaction.guild.id });

    const now = Date.now();
    const last = user.lastDaily ? new Date(user.lastDaily).getTime() : 0;
    const oneDay = 24 * 60 * 60 * 1000;

    if (now - last < oneDay) {
      const remaining = oneDay - (now - last);
      const hours = Math.floor(remaining / 3600000);
      const minutes = Math.floor((remaining % 3600000) / 60000);
      return interaction.reply({ embeds: [errorEmbed(`You already claimed your daily reward. Try again in **${hours}h ${minutes}m**.`)], ephemeral: true });
    }

    const streakBroken = now - last > oneDay * 2;
    user.dailyStreak = streakBroken ? 1 : user.dailyStreak + 1;

    const bonus = Math.min(user.dailyStreak * economy.dailyStreakBonus, 500);
    const total = economy.dailyAmount + bonus;

    user.balance += total;
    user.lastDaily = new Date();
    await user.save();

    return interaction.reply({
      embeds: [successEmbed(`You claimed your daily reward of **${total}** coins! (Streak: ${user.dailyStreak} day${user.dailyStreak > 1 ? 's' : ''}, +${bonus} bonus)`, '🪙 Daily Reward')]
    });
  }
};
