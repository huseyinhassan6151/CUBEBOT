const { SlashCommandBuilder } = require('discord.js');
const User = require('../../models/User');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pay')
    .setDescription('Send coins to another member.')
    .addUserOption(o => o.setName('user').setDescription('The member to pay').setRequired(true))
    .addIntegerOption(o => o.setName('amount').setDescription('Amount of coins to send').setRequired(true).setMinValue(1)),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');

    if (target.id === interaction.user.id) {
      return interaction.reply({ embeds: [errorEmbed('You cannot pay yourself.')], ephemeral: true });
    }
    if (target.bot) {
      return interaction.reply({ embeds: [errorEmbed('You cannot pay a bot.')], ephemeral: true });
    }

    let sender = await User.findOne({ userId: interaction.user.id, guildId: interaction.guild.id });
    if (!sender) sender = await User.create({ userId: interaction.user.id, guildId: interaction.guild.id });

    if (sender.balance < amount) {
      return interaction.reply({ embeds: [errorEmbed(`You don't have enough coins. Your balance: **${sender.balance}**`)], ephemeral: true });
    }

    let receiver = await User.findOne({ userId: target.id, guildId: interaction.guild.id });
    if (!receiver) receiver = await User.create({ userId: target.id, guildId: interaction.guild.id });

    sender.balance -= amount;
    receiver.balance += amount;
    await sender.save();
    await receiver.save();

    return interaction.reply({ embeds: [successEmbed(`You sent **${amount}** coins to ${target}.`, '💸 Payment Sent')] });
  }
};
