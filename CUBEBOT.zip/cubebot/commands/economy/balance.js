const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const User = require('../../models/User');
const { colors, emojis } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('Check your or another member\'s wallet and bank balance.')
    .addUserOption(o => o.setName('user').setDescription('The member to check').setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;

    let user = await User.findOne({ userId: target.id, guildId: interaction.guild.id });
    if (!user) user = await User.create({ userId: target.id, guildId: interaction.guild.id });

    const embed = new EmbedBuilder()
      .setColor(colors.primary)
      .setAuthor({ name: `${target.username}'s Balance`, iconURL: target.displayAvatarURL() })
      .addFields(
        { name: `${emojis.coin} Wallet`, value: `${user.balance}`, inline: true },
        { name: '🏦 Bank', value: `${user.bank}`, inline: true },
        { name: '💰 Net Worth', value: `${user.balance + user.bank}`, inline: true }
      );

    return interaction.reply({ embeds: [embed] });
  }
};
