const { SlashCommandBuilder } = require('discord.js');
const User = require('../../models/User');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { economy } = require('../../config/config');

const JOBS = [
  'delivered pizzas', 'fixed a computer', 'walked some dogs', 'wrote a bit of code',
  'streamed on Twitch', 'sold lemonade', 'mowed a lawn', 'tutored a student', 'washed cars'
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('work')
    .setDescription('Work a small job to earn coins.'),

  async execute(interaction) {
    let user = await User.findOne({ userId: interaction.user.id, guildId: interaction.guild.id });
    if (!user) user = await User.create({ userId: interaction.user.id, guildId: interaction.guild.id });

    const now = Date.now();
    const last = user.lastWork ? new Date(user.lastWork).getTime() : 0;
    const cooldown = 60 * 60 * 1000; // 1 hour

    if (now - last < cooldown) {
      const remaining = cooldown - (now - last);
      const minutes = Math.ceil(remaining / 60000);
      return interaction.reply({ embeds: [errorEmbed(`You're tired! Rest for **${minutes} more minute(s)** before working again.`)], ephemeral: true });
    }

    const earned = Math.floor(Math.random() * (economy.workMax - economy.workMin + 1)) + economy.workMin;
    const job = JOBS[Math.floor(Math.random() * JOBS.length)];

    user.balance += earned;
    user.lastWork = new Date();
    await user.save();

    return interaction.reply({ embeds: [successEmbed(`You ${job} and earned **${earned}** coins!`, '💼 Work Complete')] });
  }
};
