const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const User = require('../../models/User');
const { successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('addmoney')
    .setDescription('[Admin] Add or remove coins from a member\'s balance.')
    .addUserOption(o => o.setName('user').setDescription('The member to modify').setRequired(true))
    .addIntegerOption(o => o.setName('amount').setDescription('Amount to add (use negative to remove)').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');

    let user = await User.findOne({ userId: target.id, guildId: interaction.guild.id });
    if (!user) user = await User.create({ userId: target.id, guildId: interaction.guild.id });

    user.balance = Math.max(0, user.balance + amount);
    await user.save();

    return interaction.reply({ embeds: [successEmbed(`${target}'s balance is now **${user.balance}** coins.`)] });
  }
};
