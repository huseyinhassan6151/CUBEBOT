const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const User = require('../../models/User');
const { xpForNextLevel } = require('../../utils/xp');
const { colors } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rank')
    .setDescription('Check your or another member\'s XP rank.')
    .addUserOption(o => o.setName('user').setDescription('The member to check').setRequired(false)),

  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;

    let user = await User.findOne({ userId: target.id, guildId: interaction.guild.id });
    if (!user) user = await User.create({ userId: target.id, guildId: interaction.guild.id });

    const allUsers = await User.find({ guildId: interaction.guild.id }).sort({ xp: -1 });
    const position = allUsers.findIndex(u => u.userId === target.id) + 1;

    const needed = xpForNextLevel(user.level);
    const xpIntoLevel = user.xp - Array.from({ length: user.level }, (_, i) => i).reduce((sum, l) => sum + xpForNextLevel(l), 0);
    const progressBarLength = 20;
    const filled = Math.round((xpIntoLevel / needed) * progressBarLength);
    const bar = '█'.repeat(Math.max(0, filled)) + '░'.repeat(Math.max(0, progressBarLength - filled));

    const embed = new EmbedBuilder()
      .setColor(colors.primary)
      .setAuthor({ name: `${target.username}'s Rank`, iconURL: target.displayAvatarURL() })
      .addFields(
        { name: 'Rank', value: `#${position}`, inline: true },
        { name: 'Level', value: `${user.level}`, inline: true },
        { name: 'Total XP', value: `${user.xp}`, inline: true },
        { name: 'Progress', value: `${bar}\n${xpIntoLevel}/${needed} XP` }
      );

    return interaction.reply({ embeds: [embed] });
  }
};
