const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const User = require('../../models/User');
const { colors } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('xp-leaderboard')
    .setDescription('View the top XP earners in this server.'),

  async execute(interaction) {
    await interaction.deferReply();

    const users = await User.find({ guildId: interaction.guild.id }).sort({ xp: -1 }).limit(10);
    if (!users.length) {
      return interaction.editReply('No XP data yet for this server.');
    }

    const lines = await Promise.all(users.map(async (u, i) => {
      const member = await interaction.guild.members.fetch(u.userId).catch(() => null);
      const name = member ? member.user.username : `Unknown (${u.userId})`;
      const medal = ['🥇', '🥈', '🥉'][i] || `${i + 1}.`;
      return `${medal} **${name}** — Level ${u.level} (${u.xp} XP)`;
    }));

    const embed = new EmbedBuilder()
      .setColor(colors.primary)
      .setTitle(`✨ XP Leaderboard for ${interaction.guild.name}`)
      .setDescription(lines.join('\n'));

    return interaction.editReply({ embeds: [embed] });
  }
};
