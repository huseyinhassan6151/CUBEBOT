const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { colors } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Show all CUBEBOT commands.'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setColor(colors.primary)
      .setTitle('📦 CUBEBOT Commands')
      .setDescription('Here is everything CUBEBOT can do:')
      .addFields(
        { name: '🛡️ Moderation', value: '`/ban` `/unban` `/kick` `/mute` `/unmute` `/warn` `/warnings` `/clear`' },
        { name: '🪙 Economy', value: '`/balance` `/daily` `/work` `/pay` `/economy-leaderboard` `/addmoney`' },
        { name: '✨ XP System', value: '`/rank` `/xp-leaderboard`' },
        { name: '🎫 Tickets', value: '`/ticket-setup` `/ticket-config`' },
        { name: '⚙️ Configuration', value: '`/setwelcome` `/autoresponse`' },
        { name: '🔧 Utility', value: '`/help` `/ping`' }
      )
      .setFooter({ text: 'CUBEBOT • Full-featured Discord Bot' });

    return interaction.reply({ embeds: [embed] });
  }
};
