const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const GuildConfig = require('../../models/GuildConfig');
const { successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setwelcome')
    .setDescription('Configure the welcome message system.')
    .addSubcommand(sub => sub
      .setName('enable')
      .setDescription('Enable welcome messages')
      .addChannelOption(o => o.setName('channel').setDescription('Channel to send welcome messages in').setRequired(true))
      .addStringOption(o => o.setName('message').setDescription('Use {user} {username} {server} {count}').setRequired(false)))
    .addSubcommand(sub => sub.setName('disable').setDescription('Disable welcome messages'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    let cfg = await GuildConfig.findOne({ guildId: interaction.guild.id });
    if (!cfg) cfg = await GuildConfig.create({ guildId: interaction.guild.id });

    if (sub === 'enable') {
      const channel = interaction.options.getChannel('channel');
      const message = interaction.options.getString('message');

      cfg.welcome.enabled = true;
      cfg.welcome.channelId = channel.id;
      if (message) cfg.welcome.message = message;
      await cfg.save();

      return interaction.reply({ embeds: [successEmbed(`Welcome messages enabled in ${channel}.`)], ephemeral: true });
    }

    if (sub === 'disable') {
      cfg.welcome.enabled = false;
      await cfg.save();
      return interaction.reply({ embeds: [successEmbed('Welcome messages disabled.')], ephemeral: true });
    }
  }
};
