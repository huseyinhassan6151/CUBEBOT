const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const GuildConfig = require('../../models/GuildConfig');
const { successEmbed, errorEmbed } = require('../../utils/embeds');
const { colors } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('autoresponse')
    .setDescription('Manage automatic message responses.')
    .addSubcommand(sub => sub
      .setName('add')
      .setDescription('Add a new auto response')
      .addStringOption(o => o.setName('trigger').setDescription('Word or phrase that triggers the response').setRequired(true))
      .addStringOption(o => o.setName('response').setDescription('The bot\'s response').setRequired(true))
      .addBooleanOption(o => o.setName('exact_match').setDescription('Require the message to exactly match the trigger').setRequired(false)))
    .addSubcommand(sub => sub
      .setName('remove')
      .setDescription('Remove an auto response')
      .addStringOption(o => o.setName('trigger').setDescription('The trigger to remove').setRequired(true)))
    .addSubcommand(sub => sub.setName('list').setDescription('List all auto responses'))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    let cfg = await GuildConfig.findOne({ guildId: interaction.guild.id });
    if (!cfg) cfg = await GuildConfig.create({ guildId: interaction.guild.id });

    if (sub === 'add') {
      const trigger = interaction.options.getString('trigger');
      const response = interaction.options.getString('response');
      const exactMatch = interaction.options.getBoolean('exact_match') || false;

      cfg.autoResponses.push({ trigger, response, exactMatch });
      await cfg.save();

      return interaction.reply({ embeds: [successEmbed(`Auto response added for trigger: \`${trigger}\``)], ephemeral: true });
    }

    if (sub === 'remove') {
      const trigger = interaction.options.getString('trigger');
      const before = cfg.autoResponses.length;
      cfg.autoResponses = cfg.autoResponses.filter(ar => ar.trigger.toLowerCase() !== trigger.toLowerCase());

      if (cfg.autoResponses.length === before) {
        return interaction.reply({ embeds: [errorEmbed(`No auto response found for trigger: \`${trigger}\``)], ephemeral: true });
      }

      await cfg.save();
      return interaction.reply({ embeds: [successEmbed(`Auto response removed for trigger: \`${trigger}\``)], ephemeral: true });
    }

    if (sub === 'list') {
      if (!cfg.autoResponses.length) {
        return interaction.reply({ content: 'No auto responses configured yet.', ephemeral: true });
      }

      const embed = new EmbedBuilder()
        .setColor(colors.primary)
        .setTitle('🤖 Auto Responses')
        .setDescription(cfg.autoResponses.map(ar => `**${ar.trigger}** ${ar.exactMatch ? '(exact)' : '(contains)'} → ${ar.response}`).join('\n'));

      return interaction.reply({ embeds: [embed], ephemeral: true });
    }
  }
};
