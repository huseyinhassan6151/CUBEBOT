const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban a member from the server.')
    .addUserOption(o => o.setName('user').setDescription('The member to ban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the ban').setRequired(false))
    .addIntegerOption(o => o.setName('delete_days').setDescription('Days of messages to delete (0-7)').setMinValue(0).setMaxValue(7))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';
    const deleteDays = interaction.options.getInteger('delete_days') || 0;

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (member && !member.bannable) {
      return interaction.reply({ embeds: [errorEmbed('I cannot ban that member. Check role hierarchy.')], ephemeral: true });
    }

    await interaction.guild.members.ban(target.id, { reason, deleteMessageSeconds: deleteDays * 86400 });

    await target.send(`You have been banned from **${interaction.guild.name}**.\nReason: ${reason}`).catch(() => {});
    return interaction.reply({ embeds: [successEmbed(`**${target.tag}** has been banned.\n**Reason:** ${reason}`, '🔨 Member Banned')] });
  }
};
