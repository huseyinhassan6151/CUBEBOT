const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const User = require('../../models/User');
const { colors } = require('../../config/config');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription("View a member's warning history.")
    .addUserOption(o => o.setName('user').setDescription('The member to check').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const user = await User.findOne({ userId: target.id, guildId: interaction.guild.id });

    if (!user || !user.warnings.length) {
      return interaction.reply({ content: `${target.tag} has no warnings.`, ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setColor(colors.warning)
      .setTitle(`⚠️ Warnings for ${target.tag}`)
      .setDescription(
        user.warnings.slice(-10).map((w, i) =>
          `**${i + 1}.** ${w.reason} — <@${w.moderatorId}> (<t:${Math.floor(new Date(w.date).getTime() / 1000)}:R>)`
        ).join('\n')
      )
      .setFooter({ text: `Total warnings: ${user.warnings.length}` });

    return interaction.reply({ embeds: [embed] });
  }
};
