const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const User = require('../../models/User');
const { successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Issue a warning to a member.')
    .addUserOption(o => o.setName('user').setDescription('The member to warn').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the warning').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');

    let user = await User.findOne({ userId: target.id, guildId: interaction.guild.id });
    if (!user) user = await User.create({ userId: target.id, guildId: interaction.guild.id });

    user.warnings.push({ moderatorId: interaction.user.id, reason });
    await user.save();

    await target.send(`You have been warned in **${interaction.guild.name}**.\nReason: ${reason}`).catch(() => {});

    return interaction.reply({
      embeds: [successEmbed(`**${target.tag}** has been warned.\n**Reason:** ${reason}\n**Total warnings:** ${user.warnings.length}`, '⚠️ Member Warned')]
    });
  }
};
