const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('unban')
    .setDescription('Unban a user by their ID.')
    .addStringOption(o => o.setName('user_id').setDescription('The user ID to unban').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),

  async execute(interaction) {
    const userId = interaction.options.getString('user_id');

    try {
      await interaction.guild.members.unban(userId);
      return interaction.reply({ embeds: [successEmbed(`User with ID \`${userId}\` has been unbanned.`, '✅ Member Unbanned')] });
    } catch (err) {
      return interaction.reply({ embeds: [errorEmbed('Could not unban that user. Make sure the ID is correct and they are currently banned.')], ephemeral: true });
    }
  }
};
