const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const ms = require('ms');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('mute')
    .setDescription('Timeout (mute) a member for a duration.')
    .addUserOption(o => o.setName('user').setDescription('The member to mute').setRequired(true))
    .addStringOption(o => o.setName('duration').setDescription('Duration e.g. 10m, 1h, 1d').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the mute').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const durationStr = interaction.options.getString('duration');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const durationMs = ms(durationStr);
    if (!durationMs || durationMs < 5000 || durationMs > 2419200000) {
      return interaction.reply({ embeds: [errorEmbed('Please provide a valid duration between 5 seconds and 28 days (e.g. 10m, 1h, 1d).')], ephemeral: true });
    }

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) return interaction.reply({ embeds: [errorEmbed('That user is not in this server.')], ephemeral: true });
    if (!member.moderatable) return interaction.reply({ embeds: [errorEmbed('I cannot mute that member. Check role hierarchy.')], ephemeral: true });

    await member.timeout(durationMs, reason);

    return interaction.reply({ embeds: [successEmbed(`**${target.tag}** has been muted for **${durationStr}**.\n**Reason:** ${reason}`, '🔇 Member Muted')] });
  }
};
