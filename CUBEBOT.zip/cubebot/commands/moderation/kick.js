const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick a member from the server.')
    .addUserOption(o => o.setName('user').setDescription('The member to kick').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Reason for the kick').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),

  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason provided';

    const member = await interaction.guild.members.fetch(target.id).catch(() => null);
    if (!member) return interaction.reply({ embeds: [errorEmbed('That user is not in this server.')], ephemeral: true });
    if (!member.kickable) return interaction.reply({ embeds: [errorEmbed('I cannot kick that member. Check role hierarchy.')], ephemeral: true });

    await member.send(`You have been kicked from **${interaction.guild.name}**.\nReason: ${reason}`).catch(() => {});
    await member.kick(reason);

    return interaction.reply({ embeds: [successEmbed(`**${target.tag}** has been kicked.\n**Reason:** ${reason}`, '👢 Member Kicked')] });
  }
};
