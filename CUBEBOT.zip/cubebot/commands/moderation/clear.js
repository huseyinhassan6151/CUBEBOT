const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { successEmbed, errorEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('clear')
    .setDescription('Bulk delete messages from this channel.')
    .addIntegerOption(o => o.setName('amount').setDescription('Number of messages to delete (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption(o => o.setName('user').setDescription('Only delete messages from this user').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const user = interaction.options.getUser('user');

    await interaction.deferReply({ ephemeral: true });

    const messages = await interaction.channel.messages.fetch({ limit: 100 });
    const filtered = user ? messages.filter(m => m.author.id === user.id).first(amount) : messages.first(amount);

    if (!filtered.length) {
      return interaction.editReply({ embeds: [errorEmbed('No messages found to delete.')] });
    }

    const deleted = await interaction.channel.bulkDelete(filtered, true).catch(() => null);
    if (!deleted) {
      return interaction.editReply({ embeds: [errorEmbed('Could not delete messages (they may be older than 14 days).')] });
    }

    return interaction.editReply({ embeds: [successEmbed(`Deleted **${deleted.size}** message(s).`)] });
  }
};
