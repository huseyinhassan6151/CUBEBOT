const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getOrCreateGuildConfig, ticketPanelEmbed, ticketPanelRow } = require('../../handlers/ticketHandler');
const { successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket-setup')
    .setDescription('Post the ticket panel in a channel.')
    .addChannelOption(o => o.setName('channel').setDescription('Channel to post the panel in').setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    const cfg = await getOrCreateGuildConfig(interaction.guild.id);

    cfg.tickets.panelChannelId = channel.id;
    await cfg.save();

    await channel.send({ embeds: [ticketPanelEmbed(interaction.guild)], components: [ticketPanelRow()] });

    return interaction.reply({ embeds: [successEmbed(`Ticket panel posted in ${channel}.`)], ephemeral: true });
  }
};
