const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getOrCreateGuildConfig } = require('../../handlers/ticketHandler');
const { successEmbed } = require('../../utils/embeds');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket-config')
    .setDescription('Configure the ticket system.')
    .addSubcommand(sub => sub
      .setName('add-support-role')
      .setDescription('Add a role that can see and manage tickets')
      .addRoleOption(o => o.setName('role').setDescription('Support role').setRequired(true)))
    .addSubcommand(sub => sub
      .setName('set-log-channel')
      .setDescription('Set the channel where closed ticket logs are sent')
      .addChannelOption(o => o.setName('channel').setDescription('Log channel').setRequired(true)))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    const cfg = await getOrCreateGuildConfig(interaction.guild.id);

    if (sub === 'add-support-role') {
      const role = interaction.options.getRole('role');
      if (!cfg.tickets.supportRoleIds.includes(role.id)) {
        cfg.tickets.supportRoleIds.push(role.id);
        await cfg.save();
      }
      return interaction.reply({ embeds: [successEmbed(`${role} can now view and manage tickets.`)], ephemeral: true });
    }

    if (sub === 'set-log-channel') {
      const channel = interaction.options.getChannel('channel');
      cfg.tickets.logChannelId = channel.id;
      await cfg.save();
      return interaction.reply({ embeds: [successEmbed(`Ticket logs will now be sent to ${channel}.`)], ephemeral: true });
    }
  }
};
