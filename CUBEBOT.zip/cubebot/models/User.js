const { Schema, model } = require('mongoose');

// Per-guild per-user profile: economy + xp combined
const UserSchema = new Schema({
  userId: { type: String, required: true },
  guildId: { type: String, required: true },

  // Economy
  balance: { type: Number, default: 100 },
  bank: { type: Number, default: 0 },
  lastDaily: { type: Date, default: null },
  dailyStreak: { type: Number, default: 0 },
  lastWork: { type: Date, default: null },

  // XP / Levels
  xp: { type: Number, default: 0 },
  level: { type: Number, default: 0 },
  totalMessages: { type: Number, default: 0 },
  lastXpMessage: { type: Date, default: null },

  // Moderation history
  warnings: [
    {
      moderatorId: String,
      reason: String,
      date: { type: Date, default: Date.now }
    }
  ]
}, { timestamps: true });

UserSchema.index({ userId: 1, guildId: 1 }, { unique: true });

module.exports = model('User', UserSchema);
