const { Schema, model } = require('mongoose');

const GuildConfigSchema = new Schema({
  guildId: { type: String, required: true, unique: true },

  // Welcome system
  welcome: {
    enabled: { type: Boolean, default: false },
    channelId: { type: String, default: null },
    message: { type: String, default: 'Welcome {user} to **{server}**! You are member #{count}.' },
    imageEnabled: { type: Boolean, default: true },
    leaveEnabled: { type: Boolean, default: false },
    leaveChannelId: { type: String, default: null },
    leaveMessage: { type: String, default: '{user} has left **{server}**. Goodbye!' }
  },

  // Moderation
  moderation: {
    mutedRoleId: { type: String, default: null },
    logChannelId: { type: String, default: null },
    automod: { type: Boolean, default: false }
  },

  // Tickets
  tickets: {
    categoryId: { type: String, default: null },
    logChannelId: { type: String, default: null },
    supportRoleIds: { type: [String], default: [] },
    panelChannelId: { type: String, default: null },
    ticketCounter: { type: Number, default: 0 }
  },

  // XP
  xpSystem: {
    enabled: { type: Boolean, default: true },
    announceLevelUp: { type: Boolean, default: true },
    levelUpChannelId: { type: String, default: null }
  },

  // Auto responses: [{ trigger, response, exactMatch }]
  autoResponses: [
    {
      trigger: String,
      response: String,
      exactMatch: { type: Boolean, default: false }
    }
  ]
}, { timestamps: true });

module.exports = model('GuildConfig', GuildConfigSchema);
