const { Schema, model } = require('mongoose');

const TicketSchema = new Schema({
  guildId: { type: String, required: true },
  channelId: { type: String, required: true },
  userId: { type: String, required: true },
  ticketNumber: { type: Number, required: true },
  status: { type: String, enum: ['open', 'closed'], default: 'open' },
  reason: { type: String, default: 'No reason provided' },
  claimedBy: { type: String, default: null },
  closedBy: { type: String, default: null },
  closedAt: { type: Date, default: null }
}, { timestamps: true });

module.exports = model('Ticket', TicketSchema);
