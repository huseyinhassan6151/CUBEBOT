require('dotenv').config();

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  clientSecret: process.env.CLIENT_SECRET,
  guildId: process.env.GUILD_ID,
  mongoUri: process.env.MONGO_URI,
  ownerIds: (process.env.OWNER_IDS || '').split(',').map(id => id.trim()).filter(Boolean),

  colors: {
    primary: 0x5865F2,
    success: 0x57F287,
    danger: 0xED4245,
    warning: 0xFEE75C,
    dark: 0x2B2D31
  },

  emojis: {
    ticket: '🎫',
    coin: '🪙',
    xp: '✨',
    warn: '⚠️',
    ban: '🔨',
    kick: '👢',
    mute: '🔇',
    check: '✅',
    cross: '❌'
  },

  economy: {
    dailyAmount: 250,
    dailyStreakBonus: 25,
    workMin: 50,
    workMax: 200,
    startingBalance: 100
  },

  xp: {
    minPerMessage: 15,
    maxPerMessage: 25,
    cooldownSeconds: 60,
    levelUpFormula: (level) => 5 * (level ** 2) + 50 * level + 100
  },

  tickets: {
    categoryName: 'Tickets',
    transcriptChannelName: 'ticket-transcripts',
    maxOpenPerUser: 2
  }
};
