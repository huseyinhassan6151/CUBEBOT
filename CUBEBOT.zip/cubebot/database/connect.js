const mongoose = require('mongoose');
const { mongoUri } = require('../config/config');

async function connectDatabase() {
  if (!mongoUri) {
    console.error('[Database] MONGO_URI is missing from your .env file.');
    process.exit(1);
  }

  mongoose.set('strictQuery', true);

  try {
    await mongoose.connect(mongoUri);
    console.log('[Database] Connected to MongoDB successfully.');
  } catch (err) {
    console.error('[Database] Failed to connect to MongoDB:', err.message);
    process.exit(1);
  }

  mongoose.connection.on('disconnected', () => {
    console.warn('[Database] MongoDB disconnected. Attempting reconnect...');
  });
}

module.exports = { connectDatabase };
